from flask import Flask, render_template, request, session, redirect, url_for, flash
import sqlite3
import pandas as pd
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a secure key in production

# Load CSV and set up database connection
course_data = pd.read_csv('udemy_courses.csv')

def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

# Create a table for user authentication if it doesn't exist
def init_db():
    conn = get_db_connection()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

# Home page (redirect to index)
@app.route('/')
def home():
    return redirect(url_for('index'))

# User registration
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        hashed_password = generate_password_hash(password)

        conn = get_db_connection()
        try:
            conn.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, hashed_password))
            conn.commit()
            flash('Registration successful! You can now log in.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username already exists. Please choose a different one.', 'danger')
        finally:
            conn.close()

    return render_template('register.html')

# User login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        conn.close()

        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            flash('Login successful! Welcome back, {}'.format(user['username']), 'success')
            return redirect(url_for('index'))  # Ensure redirection to index
        else:
            flash('Invalid username or password', 'danger')

    return render_template('login.html')

# Index page to select an area of interest
@app.route('/index', methods=['GET', 'POST'])
def index():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        interest = request.form['interest']
        session['interest'] = interest
        return redirect(url_for('result'))

    return render_template('index.html')

# Show 10 related courses based on the selected area of interest
@app.route('/result')
def result():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    interest = session.get('interest')

    # Query the top 10 related courses from the CSV data
    related_courses = course_data[course_data['subject'].str.contains(interest, case=False)].head(10)

    # Pass the related courses to the template
    return render_template('result.html', courses=related_courses.to_dict(orient='records'))

# User logout
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('username', None)
    flash('You have been logged out.', 'success')
    return redirect(url_for('login'))

if __name__ == '__main__':
    init_db()  # Ensure the users table exists
    app.run(debug=True)
