from flask import Flask, render_template, request, session, redirect, url_for, flash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
import sqlite3
import pandas as pd
import random
from werkzeug.security import generate_password_hash, check_password_hash
from flask_mail import Mail, Message

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a secure key in production

# Flask-Mail configuration
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'katzkumar2617@gmail.com'
app.config['MAIL_PASSWORD'] = 'Kanaga_1906'  # For Gmail, consider using an app-specific password
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
app.config['MAIL_DEFAULT_SENDER'] = 'your_email@gmail.com'

mail = Mail(app)

# Load CSV data
course_data = pd.read_csv('udemy_courses.csv')

# Database connection helper
def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

# Initialize database tables
def init_db():
    conn = get_db_connection()
    conn.execute('''CREATE TABLE IF NOT EXISTS details (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    email TEXT NOT NULL,
                    gender TEXT NOT NULL,
                    qualification TEXT NOT NULL,
                    password TEXT NOT NULL)''')
    conn.execute('''CREATE TABLE IF NOT EXISTS feedback(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    course_title TEXT NOT NULL,
                    rating INTEGER NOT NULL,
                    feedback TEXT NOT NULL,
                    username TEXT NOT NULL,
                    FOREIGN KEY (username) REFERENCES details (username))''')
    conn.commit()
    conn.close()

# Username suggestion generator
adjectives = ['cool', 'fast', 'smart', 'creative', 'brave', 'fierce', 'wise', 'techy', 'happy', 'bold']
nouns = ['ninja', 'wizard', 'coder', 'guru', 'developer', 'master', 'hero', 'scholar', 'warrior', 'pioneer']

def generate_username_suggestions():
    suggestions = []
    for _ in range(3):
        adj = random.choice(adjectives)
        noun = random.choice(nouns)
        suggestions.append(f'{adj}_{noun}')
    return suggestions

# Configure Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# User model for Flask-Login
class User(UserMixin):
    def __init__(self, id, username):
        self.id = id
        self.username = username

@login_manager.user_loader
def load_user(user_id):
    conn = get_db_connection()
    user_data = conn.execute('SELECT * FROM details WHERE id = ?', (user_id,)).fetchone()
    conn.close()
    if user_data:
        return User(user_data['id'], user_data['username'])
    return None

# Routes
@app.route('/')
def home():
    return redirect(url_for('index'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    username_suggestions = generate_username_suggestions()
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        gender = request.form['gender']
        qualification = request.form['qualification']

        # Validate email
        if not email.endswith('@gmail.com'):
            flash('Invalid email address. Please use a Gmail address.', 'danger')
            return render_template('register.html', suggestions=username_suggestions)

        hashed_password = generate_password_hash(password)
        conn = get_db_connection()
        try:
            conn.execute('INSERT INTO details (username, email, gender, qualification, password) VALUES (?, ?, ?, ?, ?)',
                         (username, email, gender, qualification, hashed_password))
            conn.commit()
            flash('Registration successful! You can now log in.', 'success')
            return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Username already exists. Please choose a different one.', 'danger')
            username_suggestions = generate_username_suggestions()
        finally:
            conn.close()
    return render_template('register.html', suggestions=username_suggestions)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_db_connection()
        user = conn.execute('SELECT * FROM details WHERE username = ?', (username,)).fetchone()
        conn.close()

        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            flash('Login successful! Welcome back, {}'.format(user['username']), 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password', 'danger')
    return render_template('login.html')

@app.route('/index', methods=['GET', 'POST'])
def index():
    if 'username' not in session:
        return redirect(url_for('login'))
    username = session['username']
    if request.method == 'POST':
        interest = request.form['interest']
        session['interest'] = interest
        return redirect(url_for('result'))
    return render_template('index.html', username=username)

@app.route('/result')
def result():
    if 'username' not in session:
        return redirect(url_for('login'))

    interest = session.get('interest')
    print("Interest:", interest)  # Debug line

    # Ensure all values in 'subject' column are treated as strings
    course_data['subject'] = course_data['subject'].astype(str)

    # Query the top 10 related courses from the CSV data based on interest
    related_courses = course_data[course_data['subject'].str.contains(interest, case=False, na=False)].head(10)

    # Print the filtered courses for debugging
    print("Filtered Courses:", related_courses.to_dict(orient='records'))

    # Pass the related courses to the template
    return render_template('result.html', courses=related_courses.to_dict(orient='records'))


# @app.route('/feedback_form', methods=['POST'])
# def feedback_form():
#     if 'username' not in session:
#         return redirect(url_for('login'))
#     username = session['username']
#     course_title = request.form['course_title']
#     rating = int(request.form['course_rating'])
#     feedback = request.form['feedback']

#     conn = get_db_connection()
#     conn.execute('INSERT INTO feedback(course_title, rating, feedback, username) VALUES (?, ?, ?, ?)',
#                  (course_title, rating, feedback, username))
#     conn.commit()
#     conn.close()

#     flash("Thank you for your feedback!", "success")
#     return redirect(url_for('result'))

# Feedback route to save feedback
@app.route('/feedback_form', methods=['POST'])
def feedback_form():
    if 'username' not in session:
        return redirect(url_for('login'))

    username = session['username']
    course_title = request.form['course_title']
    rating = int(request.form['course_rating'])
    feedback = request.form['feedback']

    conn = get_db_connection()
    conn.execute('INSERT INTO feedback(course_title, rating, feedback, username) VALUES (?, ?, ?, ?)',
                 (course_title, rating, feedback, username))
    conn.commit()
    conn.close()

    flash("Thank you for your feedback!", "success")
    return redirect(url_for('result'))


courses = [
    {
        'course_title': 'Software Engineering',
        'description': 'Learn software development methodologies, project management, and best practices in software engineering.',
        'num_lectures': 22,
        'content_duration': 9,
        'course_rating': 4.8,  # Ensure this exists in each course dictionary
        'url': 'https://www.udemy.com/course/software-engineering/',
        'url1': 'https://www.coursera.org/learn/software-engineering',
        'url2': 'https://www.edx.org/course/software-engineering',
        'url3': 'https://www.datacamp.com/courses/software-engineering',
        'url4': 'https://www.codecademy.com/learn/software-engineering'
    },
    # Additional courses...
]


@app.route('/logout', methods=['POST'])
@login_required
def logout():
    logout_user()
    session.pop('user_id', None)
    session.pop('username', None)
    flash("You have been logged out.", "success")
    return redirect(url_for('login'))

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        message = request.form['message']
        msg = Message(f'New Message from {name}', recipients=['katzkumar2617@gmail.com'])
        msg.body = f'Name: {name}\nEmail: {email}\nMessage: {message}'
        try:
            mail.send(msg)
            flash('Your message has been sent successfully!', 'success')
        except Exception as e:
            flash(f'Failed to send message. Error: {str(e)}', 'danger')
        return redirect(url_for('contact'))
    return render_template('contact.html')

if __name__ == '__main__':
    init_db()  # Ensure the users and feedback tables exist
    app.run(debug=True)
